import React from "react";
import "./Home.css";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div id="home">
      <div className="pt-36 lg:ml-56 max-md:ml-10 max-md:gap-7 flex flex-col gap-4 max-md:text-neutral-50 md:ml-16">
        <strong className="text-6xl max-md:text-3xl">Health Care</strong>
        <h5 className="text-4xl max-md:text-xl ">For Your Family</h5>
        <div className="max-md:text-wrap">
          "At{" "}
          <strong className=" text-primary text-2xl max-md:text-xs">
            Sunmind
          </strong>
          HealthCares, we are committed to delivering quality <br />
          medications and injectable solutions that ensure the well-being of our
          patients."
        </div>
      </div>
      <div className="mt-20 flex justify-start align-middle ml-56 max-md:ml-6">
        <Link
          to="/products"
          className="rounded-md bg-indigo-600 px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-transparent hover:text-black hover:border-slate-950 border max-md:ml-0"
        >
          See our Products
        </Link>
      </div>
    </div>
  );
};

export default Home;
